package com.luki.lukiiteminspector.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class InspectConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("lukiiteminspector.json");

    public float rotationSensitivity = 3.0f;
    public float itemDistance = 0.55f;
    public float animationSpeed = 1.0f;
    public boolean showHands = true;
    public float minZoom = 0.25f;
    public float maxZoom = 1.6f;

    public static InspectConfig load() {
        InspectConfig config = new InspectConfig();
        try {
            if (Files.exists(FILE)) {
                config = GSON.fromJson(Files.readString(FILE), InspectConfig.class);
                if (config == null) config = new InspectConfig();
            }
            Files.writeString(FILE, GSON.toJson(config));
        } catch (IOException | com.google.gson.JsonParseException ignored) {
            config = new InspectConfig();
        }
        return config;
    }
}
