package com.luki.lukiiteminspector.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class LukiItemInspectorClient implements ClientModInitializer {
    public static InspectConfig CONFIG;
    public static KeyBinding inspectKey;
    public static KeyBinding resetKey;

    @Override
    public void onInitializeClient() {
        CONFIG = InspectConfig.load();
        InspectState state = InspectState.INSTANCE;

        inspectKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lukiiteminspector.inspect", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.lukiiteminspector"));
        resetKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lukiiteminspector.reset", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.lukiiteminspector"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) {
                state.stop();
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();

            if (state.inspecting) {
                // Item disappears -> stop inspecting
                if (mc.player.getMainHandStack().isEmpty() && mc.player.getOffHandStack().isEmpty()) {
                    state.inspecting = false;
                    return;
                }
                if (resetKey.wasPressed()) {
                    state.resetPose();
                }
                // Smooth the raw mouse deltas so rotation never jitters
                float smooth = 0.25f;
                state.smoothRotX += (state.rotX - state.smoothRotX) * smooth;
                state.smoothRotY += (state.rotY - state.smoothRotY) * smooth;
            }

            while (inspectKey.wasPressed()) {
                state.inspecting = !state.inspecting;
                state.resetPose();
                if (state.inspecting) {
                    state.progress = 0.0f;
                }
            }

            // Animate lift / lower
            float speed = CONFIG.animationSpeed * 0.12f;
            if (state.inspecting && state.progress < 1.0f) {
                state.progress = Math.min(1.0f, state.progress + speed);
            } else if (!state.inspecting && state.progress > 0.0f) {
                state.progress = Math.max(0.0f, state.progress - speed);
            }
        });
    }
}
