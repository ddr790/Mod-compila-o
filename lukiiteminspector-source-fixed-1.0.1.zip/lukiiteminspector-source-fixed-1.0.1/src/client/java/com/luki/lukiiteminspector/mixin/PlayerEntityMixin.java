package com.luki.lukiiteminspector.mixin;

import com.luki.lukiiteminspector.client.InspectState;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * While inspecting, the player's look direction must not change at all:
 * mouse movement rotates the item, never the camera.
 */
@Mixin(Entity.class)
public class PlayerEntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void luki$freezeCamera(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        if (InspectState.INSTANCE.inspecting) {
            ci.cancel();
        }
    }
}
