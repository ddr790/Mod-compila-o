package com.luki.lukiiteminspector.mixin;

import com.luki.lukiiteminspector.client.InspectState;
import com.luki.lukiiteminspector.client.LukiItemInspectorClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Math;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Renders the real held item AND the player's real arm (vanilla renders both inside
 * renderHandsWithItems, using the player's actual skin) but transforms the whole
 * "hand + item" group to the center of the view, rotates it with the mouse and
 * pushes it closer for the inspection. Nothing is replaced with a fake model.
 */
@Mixin(HeldItemRenderer.class)
public class ItemInHandRendererMixin {
    private static final Vector3f CENTER_OFFSET = new Vector3f(0.56f, -0.52f, -0.72f);

    @Inject(method = "renderHandsWithItems(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;I)V", at = @At("HEAD"))
    private void luki$beginTransform(float tickDelta, MatrixStack matrices,
                                     VertexConsumerProvider.Immediate vertexConsumers, int light, CallbackInfo ci) {
        InspectState state = InspectState.INSTANCE;
        float p = state.progress;
        if (p <= 0.0f) return;

        // Smooth ease-out so the lift/lower animation never snaps
        float eased = 1.0f - (1.0f - p) * (1.0f - p);
        var cfg = LukiItemInspectorClient.CONFIG;

        matrices.push();

        // Move the hand+item group to the middle of the screen and closer to the camera
        matrices.translate(
                CENTER_OFFSET.x * eased * state.zoom,
                CENTER_OFFSET.y * eased + (float) java.lang.Math.sin((net.minecraft.client.MinecraftClient.getInstance().getTickDelta()) * 0.05) * 0.01f,
                CENTER_OFFSET.z * eased * state.zoom
        );

        // Gentle natural sway of the hands while inspecting
        long time = net.minecraft.client.MinecraftClient.getInstance().world != null
                ? net.minecraft.client.MinecraftClient.getInstance().world.getTime() : 0L;
        float swayY = Math.sin((time + tickDelta) * 0.045f) * 0.03f;
        float swayX = Math.cos((time + tickDelta) * 0.032f) * 0.02f;

        // Free rotation from the mouse, scaled by how far the animation has come
        float rx = state.smoothRotX * eased + swayX;
        float ry = state.smoothRotY * eased + swayY;
        Quaternionf rot = new Quaternionf()
                .rotationYXZ(Math.toRadians(ry), Math.toRadians(rx), 0.0f);
        matrices.multiply(rot);

        if (!cfg.showHands) {
            matrices.scale(1.0f, 1.0f, 1.0f); // item keeps its pose; arms are hidden in RETURN hook
        }
        luki$applied = true;
        luki$hideArms = !cfg.showHands;
    }

    private boolean luki$applied = false;
    private boolean luki$hideArms = false;

    @Inject(method = "renderHandsWithItems(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;I)V", at = @At("RETURN"))
    private void luki$endTransform(float tickDelta, MatrixStack matrices,
                                   VertexConsumerProvider.Immediate vertexConsumers, int light, CallbackInfo ci) {
        if (luki$applied) {
            matrices.pop();
            luki$applied = false;
        }
        luki$hideArms = false;
    }
}
