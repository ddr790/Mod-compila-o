package com.luki.lukiiteminspector.mixin;

import com.luki.lukiiteminspector.client.InspectState;
import net.minecraft.client.Mouse;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Captures raw mouse movement for item rotation and the scroll wheel for zoom,
 * cancelling the normal in-game effects (scrolling hotbar, zooming) while inspecting.
 */
@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Shadow private double cursorDeltaX;
    @Shadow private double cursorDeltaY;

    @Inject(method = "updateMouse", at = @At("HEAD"), cancellable = true)
    private void luki$captureRotation(CallbackInfo ci) {
        InspectState state = InspectState.INSTANCE;
        if (!state.inspecting) return;

        double dx = cursorDeltaX;
        double dy = cursorDeltaY;
        if (dx != 0.0 || dy != 0.0) {
            float sens = (float) (com.luki.lukiiteminspector.client.LukiItemInspectorClient.CONFIG.rotationSensitivity / 200.0);
            state.rotY += (float) (dx * sens);
            state.rotX += (float) (dy * sens);
            state.rotX = Math.max(-135.0f, Math.min(135.0f, state.rotX));
            cursorDeltaX = 0.0;
            cursorDeltaY = 0.0;
        }
        // still run the rest so cursor position updates normally, but turning is cancelled elsewhere
    }

    @Inject(method = "onMouseScroll(JDD)V", at = @At("HEAD"), cancellable = true)
    private void luki$captureScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        InspectState state = InspectState.INSTANCE;
        if (!state.inspecting) return;

        if (vertical != 0.0) {
            var cfg = com.luki.lukiiteminspector.client.LukiItemInspectorClient.CONFIG;
            state.zoom += (float) (vertical * 0.1);
            state.zoom = Math.max(cfg.minZoom, Math.min(cfg.maxZoom, state.zoom));
        }
        ci.cancel();
    }
}
