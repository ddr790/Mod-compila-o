package com.luki.lukiiteminspector.client;

/** Holds all mutable inspection state shared between the tick handler and the render mixins. */
public final class InspectState {
    public static InspectState INSTANCE = new InspectState();

    public boolean inspecting = false;
    /** 0 = hidden, 1 = fully presented. Eased over time for the lift/lower animation. */
    public float progress = 0.0f;
    public float rotX = 0.0f;   // pitch-like rotation from vertical mouse movement
    public float rotY = 0.0f;   // yaw-like rotation from horizontal mouse movement
    public float zoom = 1.0f;   // scroll wheel multiplier
    /** Smoothed mouse deltas, used instead of raw deltas to avoid jitter. */
    public float smoothRotX = 0.0f;
    public float smoothRotY = 0.0f;

    public void resetPose() {
        rotX = 0.0f;
        rotY = 0.0f;
        smoothRotX = 0.0f;
        smoothRotY = 0.0f;
        zoom = 1.0f;
    }

    public void stop() {
        inspecting = false;
        resetPose();
    }
}
